import 'package:flutter/material.dart';

class DonationPage extends StatelessWidget {
  const DonationPage({super.key});

  @override
  Widget build(BuildContext context) {
    final TextEditingController _nameController = TextEditingController();
    final TextEditingController _amountController = TextEditingController();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Donation Form'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Donor Name'),
            ),
            TextField(
              controller: _amountController,
              decoration: const InputDecoration(labelText: 'Donation Amount'),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Check if the donor name or donation amount is empty
                if (_nameController.text.isEmpty || _amountController.text.isEmpty) {
                  // If either is empty, navigate to the Failure page
                  Navigator.pushNamed(context, '/failurePage');
                } else {
                  // Otherwise, pass the donor's name and donation amount to the Success page
                  Navigator.pushNamed(
                    context,
                    '/successPage',
                    arguments: {
                      'donorName': _nameController.text,
                      'donationAmount': _amountController.text,
                    },
                  );
                }
              },
              child: const Text("Donate Now"),
            ),
          ],
        ),
      ),
    );
  }
}
