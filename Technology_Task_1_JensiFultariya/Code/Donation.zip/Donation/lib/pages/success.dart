import 'package:flutter/material.dart';

class SuccessPage extends StatelessWidget {
  const SuccessPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Retrieve the arguments from the Navigator (using ModalRoute)
    final arguments = ModalRoute.of(context)!.settings.arguments as Map<String, String>;

    // Extract donor name and donation amount
    final donorName = arguments['donorName'] ?? 'Unknown';
    final donationAmount = arguments['donationAmount'] ?? '0';

    return Scaffold(
      appBar: AppBar(
        title: const Text("Donation Success"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Thank you for your donation!',
              style: Theme.of(context).textTheme.headlineLarge,
            ),
            SizedBox(height: 20),
            Text('Donor Name: $donorName'),
            Text('Donation Amount: \$ $donationAmount'),
          ],
        ),
      ),
    );
  }
}
