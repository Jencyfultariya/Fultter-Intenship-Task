class DonationModel {
  final String name;
  final double amount;

  DonationModel({required this.name, required this.amount});
}
