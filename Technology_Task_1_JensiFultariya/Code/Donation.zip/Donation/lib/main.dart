import 'package:donation/pages/failure.dart';
import 'package:donation/pages/success.dart';
import 'package:flutter/material.dart';
import 'pages/donation_page.dart';



void main() {
  runApp(const DonationApp());
}

class DonationApp extends StatelessWidget {
  const DonationApp({super.key});

  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const DonationPage(),
        '/successPage': (context) => const SuccessPage(),
        '/failurePage': (context) => const FailurePage(),
      },
    );
  }

}
