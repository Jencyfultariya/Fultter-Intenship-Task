import '../models/donation_model.dart';

class DonationProvider {
  bool processDonation(DonationModel donation) {
    // Simulate random success or failure
    return donation.amount > 0 && DateTime.now().second % 2 == 0;
  }
}
