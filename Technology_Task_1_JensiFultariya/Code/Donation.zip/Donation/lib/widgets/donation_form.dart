import 'package:flutter/material.dart';
import '../models/donation_model.dart';
import '../providers/donation_provider.dart';

class DonationForm extends StatefulWidget {
  @override
  _DonationFormState createState() => _DonationFormState();
}

class _DonationFormState extends State<DonationForm> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _amountController = TextEditingController();

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      final donation = DonationModel(
        name: _nameController.text,
        amount: double.parse(_amountController.text),
      );

      final provider = DonationProvider();
      bool isSuccess = provider.processDonation(donation);

      if (isSuccess) {
        Navigator.pushNamed(context, '/success');
      } else {
        Navigator.pushNamed(context, '/failure');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          TextFormField(
            controller: _nameController,
            decoration: InputDecoration(labelText: 'Name'),
            validator: (value) =>
            value == null || value.isEmpty ? 'Name is required' : null,
          ),
          TextFormField(
            controller: _amountController,
            decoration: InputDecoration(labelText: 'Donation Amount'),
            keyboardType: TextInputType.number,
            validator: (value) {
              if (value == null || value.isEmpty) return 'Amount is required';
              if (double.tryParse(value) == null ||
                  double.parse(value) <= 0) {
                return 'Enter a valid amount';
              }
              return null;
            },
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: _submitForm,
            child: Text('Donate'),
          ),
        ],
      ),
    );
  }
}
