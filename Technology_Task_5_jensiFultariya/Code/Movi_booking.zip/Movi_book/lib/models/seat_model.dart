class Seat {
  final String id;
  bool isBooked;
  bool isSelected;

  Seat({required this.id, this.isBooked = false, this.isSelected = false});
}
