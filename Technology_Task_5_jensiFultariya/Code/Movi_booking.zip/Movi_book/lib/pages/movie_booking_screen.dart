import 'package:flutter/material.dart';
import '../models/seat_model.dart';
import '../widgets/seat_widget.dart';

class MovieBookingScreen extends StatefulWidget {
  const MovieBookingScreen({Key? key}) : super(key: key);

  @override
  State<MovieBookingScreen> createState() => _MovieBookingScreenState();
}

class _MovieBookingScreenState extends State<MovieBookingScreen> {
  final List<Seat> seats = List.generate(
    30,
        (index) => Seat(
      id: (index + 1).toString(),
      isBooked: index % 5 == 0, // Every 5th seat is pre-booked
    ),
  );

  List<Seat> selectedSeats = [];

  void toggleSelection(Seat seat) {
    setState(() {
      seat.isSelected = !seat.isSelected;
      if (seat.isSelected) {
        selectedSeats.add(seat);
      } else {
        selectedSeats.remove(seat);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Movie Booking'),
      ),
      body: Column(
        children: [
          const SizedBox(height: 16),
          const Text(
            'Select Your Seats',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 6, // 6 seats per row
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
              ),
              itemCount: seats.length,
              itemBuilder: (context, index) {
                final seat = seats[index];
                return SeatWidget(
                  seat: seat,
                  onTap: () => toggleSelection(seat),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton(
              onPressed: selectedSeats.isNotEmpty
                  ? () {
                // Handle booking confirmation
                final seatIds =
                selectedSeats.map((seat) => seat.id).join(', ');
                showDialog(
                  context: context,
                  builder: (_) => AlertDialog(
                    title: const Text('Booking Confirmed'),
                    content: Text('Seats: $seatIds'),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('OK'),
                      ),
                    ],
                  ),
                );
              }
                  : null,
              child: const Text('Confirm Booking'),
            ),
          ),
        ],
      ),
    );
  }
}
