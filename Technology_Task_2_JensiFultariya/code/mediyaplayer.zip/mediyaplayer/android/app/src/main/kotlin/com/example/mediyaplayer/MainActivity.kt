package com.example.mediyaplayer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
