import 'package:flutter/material.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'YouTube Media Player',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: YouTubePlayerScreen(),
    );
  }
}

class YouTubePlayerScreen extends StatefulWidget {
  @override
  _YouTubePlayerScreenState createState() => _YouTubePlayerScreenState();
}

class _YouTubePlayerScreenState extends State<YouTubePlayerScreen> {
  late YoutubePlayerController _controller;

  @override
  void initState() {
    super.initState();

    // Initialize the YouTube player controller
    _controller = YoutubePlayerController(
      initialVideoId: 'dQw4w9WgXcQ', // Example video ID
      flags: YoutubePlayerFlags(
        autoPlay: true,  // Automatically play the video
        mute: false,     // Unmute the video
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();  // Dispose of the controller when the widget is destroyed
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('YouTube Media Player'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Embed the YouTube player widget
            YoutubePlayer(
              controller: _controller,
              showVideoProgressIndicator: true,
              progressIndicatorColor: Colors.blue,
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: ElevatedButton(
                onPressed: () {
                  // Load a new video by changing the video ID
                  setState(() {
                    _controller.load('M7lc1UVf-VE'); // Example new video ID
                  });
                },
                child: Text('Load New Video'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
