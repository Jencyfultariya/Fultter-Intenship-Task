package com.example.imagecroper

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
