// lib/widgets/category_item.dart
import 'package:flutter/material.dart';
import '../models/category.dart';

class CategoryItem extends StatelessWidget {
  final Category category;
  final VoidCallback onTap;

  CategoryItem({required this.category, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
      elevation: 5,
      child: ListTile(
        contentPadding: EdgeInsets.all(10),
        leading: Image.network(category.gifUrl, width: 50, height: 50, fit: BoxFit.cover),
        title: Text(category.name, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        onTap: onTap,  // Execute onTap when tapped
      ),
    );
  }
}
