import 'package:flutter/material.dart';

class CategoryDetailPage extends StatelessWidget {
  final String categoryName;
  final String gifPath;

  CategoryDetailPage({required this.categoryName, required this.gifPath});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          categoryName,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        backgroundColor: Colors.teal, // Custom AppBar background color
      ),
      body: Padding(
        padding: EdgeInsets.all(12.0), // Padding around the body content
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Card(
              elevation: 5, // Adds shadow effect to the card
              margin: EdgeInsets.symmetric(vertical: 10),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10), // Rounded corners for the card
              ),
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  categoryName,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.teal[700], // Text color
                  ),
                ),
              ),
            ),
            SizedBox(height: 100),
            Container(
              width: 400, // Fixed width for the image
              height: 400, // Fixed height for the image
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12), // Rounded corners for the image container
                border: Border.all(
                  color: Colors.teal.shade200,
                  width: 2,
                ),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.asset(
                  gifPath,
                  fit: BoxFit.cover, // Adjust image aspect ratio
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
