import 'package:flutter/material.dart';
import 'category_detail_page.dart';

class CategoryListPage extends StatelessWidget {
  final List<Map<String, String>> categories = [
    {
      'name': 'Nature',
      'gif': 'assets/images/Nature.webp',
    },
    {
      'name': 'Sports',
      'gif': 'assets/images/Spotes.webp',
    },
    {
      'name': 'Technology',
      'gif': 'assets/images/Tecnology.webp',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Category List'),
        backgroundColor: Colors.teal, // Custom background color for the AppBar
      ),
      body: Padding(
        padding: EdgeInsets.all(8.0), // Padding around the ListView
        child: ListView.builder(
          itemCount: categories.length,
          itemBuilder: (context, index) {
            var category = categories[index];

            return Card(
              elevation: 5, // Shadow effect for the card
              margin: EdgeInsets.symmetric(vertical: 10), // Spacing between items
              child: ListTile(
                contentPadding: EdgeInsets.all(16), // Padding inside each list tile
                leading: Icon(
                  Icons.category, // Icon for each category
                  color: Colors.teal,
                  size: 40,
                ),
                title: Text(
                  category['name'] ?? 'Unknown Category',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.teal[800],
                  ),
                ),
                subtitle: Text(
                  'Tap to see more details',
                  style: TextStyle(
                    color: Colors.grey[600],
                  ),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => CategoryDetailPage(
                        categoryName: category['name'] ?? 'Unknown Category',
                        gifPath: category['gif'] ?? 'assets/images/default.gif',
                      ),
                    ),
                  );
                },
              ),
            );
          },
        ),
      ),
    );
  }
}
