class Category {
  final String name;
  final String gifUrl;

  Category({required this.name, required this.gifUrl});
}
