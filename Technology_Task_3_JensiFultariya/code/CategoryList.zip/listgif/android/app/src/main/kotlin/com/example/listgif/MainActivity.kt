package com.example.listgif

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
